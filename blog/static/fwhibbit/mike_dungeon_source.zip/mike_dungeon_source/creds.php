<?php

if (basename($_SERVER['PHP_SELF']) === "creds.php") {
    echo '$flag = "flag{H4H4_K33P_Try1nG}"';
    die();
}

$user = "mike";
$pwd = 10932435112;
$flag = "flag{try_to_pwn_it_;)}";

?>